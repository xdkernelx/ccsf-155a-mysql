Use a_testbed;

/* demo 01 */
Select
  z_id
, z_name
, z_type
, z_cost
, z_dob
, z_acquired
From a_testbed.zoo_2016;

/* demo 02 */
Select
  z_id
, z_name
, z_type
, z_cost
From a_testbed.zoo_2016
Where z_type = 'Armadillo';

/* demo 03 */
Select
  z_id
, z_name
, z_type
, z_cost
From a_testbed.zoo_2016
Where z_cost = 5000;

/* demo 04 */
Select
  z_id
, z_name
, z_type
, z_cost
From a_testbed.zoo_2016
Where z_type = 'Unicorn';

/* demo 05 */
Insert Into zoo_2016  (
  z_id
, z_name
, z_type
, z_cost
, z_dob
, z_acquired
) values 
(
  257
, 'Arnold'
, 'Giraffe'
, 5000.00
, '2014-05-15'
, '2014-05-15'
);

Insert Into zoo_2016  (
  z_id
, z_type
, z_cost
, z_dob
, z_acquired
) values 
(
  258
, 'Giraffe'
, 5000.00
, '2013-05-15'
, '2013-05-15'
       );

Insert Into zoo_2016 values 
(
  259
, null
, 'Giraffe'
, 5000.00
, '2002-05-15'
, '2002-05-15'
       );
	   
Insert Into zoo_2016 VALUES 
   ( 
     260
, 'Geoff'
,'Giraffe'
, 5000.00
, '2002-05-15 10:45:00'
, '2002-05-15'
);

Insert Into zoo_2016 values 
(  261, 'Artemis',  'Giraffe', 1500.00, '2013-06-06 10:45:00','2013-08-15' )
,
(  262, 'Diana', 'Giraffe', 120.95, '2000-06-06 10:47:00','2015-01-15' )
;


select * 
from zoo_2016
where z_type = 'giraffe';


/*   demo 06  */
/*  additional inserts */

  
Insert Into zoo_2016 (z_id, z_name, z_type, z_cost, z_dob, z_acquired) 
 Values  (370, 'Anders', 'armadillo', 490.00, '2013-01-15 08:30:00', '2013-04-15');

Insert Into zoo_2016 (z_id, z_name, z_type, z_cost, z_dob, z_acquired)
  Values (371, 'Anne', 'armadillo', 490.01, '2013-01-15 08:30:00', '2013-04-15');

Insert Into zoo_2016 (z_id, z_name, z_type, z_cost, z_dob, z_acquired)
  Values (372, 'Leon', 'Lion', 1850.00, '2013-02-25 15:00:00', '2013-03-25');

Insert Into zoo_2016 (z_id, z_name, z_type, z_cost, z_dob, z_acquired)
  Values (373, null, 'Lion', 1850.00, '2013-02-25 15:00:00', '2013-03-25');

Insert Into zoo_2016 (z_id, z_name, z_type, z_cost, z_dob, z_acquired)
  Values (374, null, 'Lion', 1850.00, '2013-02-25 15:00:00', '2013-03-25');

Insert Into zoo_2016 (z_id, z_name, z_type, z_cost, z_dob, z_acquired)
  Values (375, '', 'Lion', 1850.00, '2013-02-25 15:00:00', '2013-03-25');
  

  